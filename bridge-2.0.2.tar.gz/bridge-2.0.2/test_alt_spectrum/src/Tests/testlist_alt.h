/*
        @file    testlist_accel.h
        @brief
        @author  Hideo Matsufuru
                 $LastChangedBy: matufuru $
        @date    $LastChangedDate: 2013-04-08 18:00:27 #$
        @version $LastChangedRevision: 2472 $
*/

#ifndef TESTLIST_ALT_INCLUDED
#define TESTLIST_ALT_INCLUDED


#ifdef USE_ALT_QXS
namespace Test_alt_QXS {
  int test_all();
}
#endif


#endif
